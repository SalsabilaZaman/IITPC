#include<stdio.h>
#include<string.h>
int main(){

    int a[3];

    a[0] = 3;
    a[1] = 500;
    a[2] = 250;

    int x = a[0] + a[2];
    printf("%d\n",x);

    a[2]=100;
    x = a[0] + a[2];
    printf("%d\n", x);

    return 0;
}