/*
                                            COFFEE MAKER
        Input: Coffee, water, sugar, creamer
        Output: Coffee
                                            OIL FACTORY
        Input: bean, water, chemicals
        output: oil cans


FUNCTION
1.Function Name                        |     ret_type func_name(input1,input2,... ...){                                                                                         }
2.Input/Arguments/Parameters           |        statements;
3.return type                          |        return result;
4.Func body                            |     }



int get_sum(int x,int y){
    sum= x + y;
    return sum;
}

void say_hi(){
    printf("Hi");
}

*/
