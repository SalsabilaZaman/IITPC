package assignment_2;

public class MyMain {

	public static void main(String[] args) 
	{
		Book b1 = new Book( "The Kite Runner" , "Ab", "01" , 7 );
		Book b2 = new Book( "Da Vinci Code" , "Cb", "02" , 10 );
		Book b3 = new Book( "The Alchemist" , "Pb", "02" , 5 );
		
		Library lib[] = new Library[3];
		lib[0] = new Library(b1, 0);
		lib[1] = new Library(b2, 1);
		lib[2] = new Library(b3, 2);
		
		for( int i=0; i<3 ; i++)
		{
			System.out.print( lib[i].book[i].title + ". Written by : ");
			System.out.print( lib[i].book[i].author + ". ISBN no : ");
			System.out.print( lib[i].book[i].ISBN + ". Remains : ");
			System.out.println( lib[i].book[i].copies + " copies");
		}
		
		Book s1[]= { b1, b2 };
		Book s2[]= {  };
		Book s3[]= { b1, b1 };
		Book s4[]= { b1, b2, b3 };
		Book s5[]= { b2 };
		
		Student student[] = new Student[10];
		student[0] = new Student("John", 1001, 2, s1 );
        student[1] = new Student("Mary", 1002, 0, s2 );
        student[3] = new Student("Peter", 1003, 2, s3 );
        student[4] = new Student("Jane", 1004, 3, s4 );
        student[5] = new Student("David", 1005, 1, s5 );
        
        student[4].display();


	}

}
