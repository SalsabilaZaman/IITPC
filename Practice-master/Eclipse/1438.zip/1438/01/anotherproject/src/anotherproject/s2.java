package anotherproject;
import f1.s1;

public class s2 
{
	public static void main(String[] args)
	{
		s1.main(args);
	}
}
