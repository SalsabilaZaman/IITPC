package f1;

public class s1
{

	public static void main(String[] args) 
	{		
		int a=28;
		int b=5;
		int c=a/b;
		int d=(a-b*c);
		
		System.out.println("The quotient and remainder after the division are "+c+" , "+d);
	}

}
