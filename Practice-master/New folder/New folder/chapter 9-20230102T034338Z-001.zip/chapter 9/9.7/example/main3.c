#include<stdio.h>

int main()
{

    rename("file3.txt", "file33.txt");

    return 0;
}
